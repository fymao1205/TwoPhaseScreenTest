expit.f <- function(x){u=exp(x); u/(1+u)}
